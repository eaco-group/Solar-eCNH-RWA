import { useLanguage } from '../contexts/languageContext';
import { motion } from 'framer-motion';

export function DesignSection() {
  const { t } = useLanguage();
  
  // 设计原则数据
  const designPrinciples = [
    { icon: 'fa-shield-halved', title: '安全可靠', description: '优先保障电站运行安全，确保长期稳定发电' },
    { icon: 'fa-bolt', title: '高效节能', 'description': '优化组件布局和系统设计，提升发电效率' },
    { icon: 'fa-money-bill-wave', title: '经济合理', description: '平衡投资成本与收益回报，实现最佳性价比' },
    { icon: 'fa-globe', title: '适配当地', description: '结合越南气候条件及厂房实际需求进行定制设计' },
    { icon: 'fa-tools', title: '便于运维', description: '简化运维流程，降低运维成本，提升管理效率' },
    { icon: 'fa-chart-line', title: '可量化监测', description: '实现发电量、收益的精准量化，为管理决策提供数据支撑' }
  ];
  
  // 组件布局设计数据
  const layoutDesigns = [
    { title: '遮挡规避', description: '全面排查屋顶附属设施，组件布局避开遮挡区域；若存在局部遮挡，采用"分组排布、错峰布局"' },
    { title: '安装倾角', description: '越南地处北半球低纬度地区，最优安装倾角约为当地纬度±2°，结合不同区域辐照量，调整倾角至15°-25°' },
    { title: '组件朝向', description: '优先采用朝南布局，若屋顶存在东西朝向区域，可合理布局组件，补充发电量；避免朝北布局' },
    { title: '检修通道', description: '每排布10-15块组件，预留1.2-1.5m宽检修通道，大型项目需增设主检修通道，便于后期运维' }
  ];
  
  return (
    <section id="design" className="py-20 bg-white dark:bg-gray-900">
      <div className="container mx-auto px-4">
        <motion.div
          className="text-center mb-16"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
        >
          <h2 className="text-3xl font-bold text-gray-900 dark:text-white mb-4">{t('design.section')}</h2>
          <div className="w-20 h-1 bg-gradient-to-r from-blue-500 to-green-500 mx-auto rounded-full"></div>
        </motion.div>
        
        {/* 设计原则 */}
        <motion.div
          className="mb-16"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
        >
          <h3 className="text-2xl font-bold text-gray-900 dark:text-white mb-8">{t('design.principle')}</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {designPrinciples.map((principle, index) => (
              <motion.div
                key={index}
                className="bg-white dark:bg-gray-800 p-6 rounded-xl shadow-lg border border-gray-100 dark:border-gray-700"
                whileHover={{ y: -5 }}
                transition={{ duration: 0.3 }}
              ><div className="w-12 h-12 bg-blue-100 dark:bg-blue-900/30 rounded-lg flex items-center justify-center mb-4">
                  <i className={`fa-solid ${principle.icon} text-blue-600 dark:text-blue-400 text-xl`}></i>
                </div>
                <h4 className="text-lg font-semibold text-gray-800 dark:text-white mb-2">{principle.title}</h4>
                <p className="text-gray-600 dark:text-gray-300">{principle.description}</p>
              </motion.div>
            ))}
          </div>
        </motion.div>
        
        {/* 装机容量测算 */}
        <motion.div
          className="mb-16 bg-gradient-to-r from-blue-50 to-green-50 dark:from-gray-850 dark:to-gray-800 p-8 rounded-2xl shadow-xl"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
        >
          <div className="flex items-center mb-6">
            <div className="w-12 h-12 bg-green-100 dark:bg-green-900/30 rounded-lg flex items-center justify-center mr-4">
              <i className="fa-solid fa-calculator text-green-600 dark:text-green-400 text-xl"></i>
            </div>
            <h3 className="text-2xl font-bold text-gray-900 dark:text-white">{t('design.capacity')}</h3>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="bg-white dark:bg-gray-800 p-6 rounded-xl shadow-lg border border-gray-100 dark:border-gray-700">
              <h4 className="text-lg font-semibold text-gray-800 dark:text-white mb-4">可利用面积</h4>
              <div className="space-y-3">
                <div className="flex justify-between">
                  <span className="text-gray-600 dark:text-gray-300">保守值 (70%)</span>
                  <span className="font-medium text-blue-600 dark:text-blue-400">560,000㎡</span>
                </div>
                <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2.5">
                  <div className="bg-blue-600 h-2.5 rounded-full" style={{ width: '70%' }}></div>
                </div>
                
                <div className="flex justify-between">
                  <span className="text-gray-600 dark:text-gray-300">乐观值 (85%)</span>
                  <span className="font-medium text-green-600 dark:text-green-400">680,000㎡</span>
                </div>
                <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2.5">
                  <div className="bg-green-600 h-2.5 rounded-full" style={{ width: '85%' }}></div>
                </div>
              </div>
            </div>
            
            <div className="bg-white dark:bg-gray-800 p-6 rounded-xl shadow-lg border border-gray-100 dark:border-gray-700">
              <h4 className="text-lg font-semibold text-gray-800 dark:text-white mb-4">组件排布密度</h4>
              <p className="text-gray-600 dark:text-gray-300 mb-4">选用550W-600W单晶硅高效组件，单块组件尺寸约1.7m×1.1m</p>
              <div className="flex justify-between items-center mt-2">
                <span className="text-gray-600 dark:text-gray-300">排布密度</span>
                <span className="font-medium text-blue-600 dark:text-blue-400">0.45-0.5kW/㎡</span>
              </div>
            </div>
            
            <div className="bg-white dark:bg-gray-800 p-6 rounded-xl shadow-lg border border-gray-100 dark:border-gray-700">
              <h4 className="text-lg font-semibold text-gray-800 dark:text-white mb-4">预估装机容量</h4>
              <div className="space-y-4">
                <div>
                  <div className="flex justify-between mb-1">
                    <span className="text-gray-600 dark:text-gray-300 text-sm">保守估算</span>
                    <span className="font-medium text-blue-600 dark:text-blue-400">252MW</span>
                  </div>
                  <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2">
                    <div className="bg-blue-600 h-2 rounded-full" style={{ width: '75%' }}></div>
                  </div>
                </div>
                
                <div>
                  <div className="flex justify-between mb-1">
                    <span className="text-gray-600 dark:text-gray-300 text-sm">建议容量</span>
                    <span className="font-medium text-green-600 dark:text-green-400">280-320MW</span>
                  </div>
                  <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2">
                    <div className="bg-green-600 h-2 rounded-full" style={{ width: '90%' }}></div>
                  </div>
                </div>
                
                <div>
                  <div className="flex justify-between mb-1">
                    <span className="text-gray-600 dark:text-gray-300 text-sm">乐观估算</span>
                    <span className="font-medium text-purple-600 dark:text-purple-400">340MW</span>
                  </div>
                  <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2">
                    <div className="bg-purple-600 h-2 rounded-full" style={{ width: '100%' }}></div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </motion.div>
        
        {/* 组件布局设计 */}
        <motion.div
          className="mb-16"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
        >
          <h3 className="text-2xl font-bold text-gray-900 dark:text-white mb-8">{t('design.layout')}</h3>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {layoutDesigns.map((layout, index) => (
              <motion.div
                key={index}
                className="bg-white dark:bg-gray-800 p-6 rounded-xl shadow-lg border border-gray-100 dark:border-gray-700"
                whileHover={{ scale: 1.02 }}
                transition={{ duration: 0.3 }}
              >
                <h4 className="text-lg font-semibold text-blue-600 dark:text-blue-400 mb-3">{layout.title}</h4>
                <p className="text-gray-600 dark:text-gray-300">{layout.description}</p>
              </motion.div>
            ))}
          </div>
          
          {/* 组件布局图示 */}
          <div className="mt-8 bg-white dark:bg-gray-800 p-6 rounded-xl shadow-lg border border-gray-100 dark:border-gray-700">
            <div className="relative h-64 md:h-80 bg-gray-100 dark:bg-gray-700 rounded-lg flex items-center justify-center overflow-hidden">
              <img 
                src="https://space.coze.cn/api/coze_space/gen_image?image_size=landscape_16_9&prompt=Solar%20panel%20installation%20on%20factory%20roof%2C%20aerial%20view%2C%203D%20illustration&sign=a9bf671166dd8f231185b8a2de7185ab" 
                alt="光伏组件布局图示" 
                className="w-full h-full object-cover"
              />
              <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/60 to-transparent p-4">
                <p className="text-white text-center text-sm">光伏组件屋顶布局示意图</p>
              </div>
            </div>
          </div>
        </motion.div>
        
        {/* 支架系统设计 */}
        <motion.div
          className="mb-16"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
        >
          <h3 className="text-2xl font-bold text-gray-900 dark:text-white mb-8">{t('design.bracket')}</h3>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div className="bg-white dark:bg-gray-800 p-6 rounded-xl shadow-lg border border-gray-100 dark:border-gray-700">
              <h4 className="text-lg font-semibold text-gray-800 dark:text-white mb-4 flex items-center">
                <i className="fa-solid fa-roof-top text-blue-600 dark:text-blue-400 mr-2"></i>
                彩钢瓦屋面支架
              </h4>
              <ul className="space-y-3 text-gray-600 dark:text-gray-300">
                <li className="flex items-start">
                  <i className="fa-solid fa-check-circle text-green-500 mt-1 mr-2"></i>
                  <span>材质：铝合金（6063-T5），重量轻、防腐性好、安装便捷</span>
                </li>
                <li className="flex items-start">
                  <i className="fa-solid fa-check-circle text-green-500 mt-1 mr-2"></i>
                  <span>固定方式：采用夹具固定，避免破坏彩钢瓦屋面结构</span>
                </li>
                <li className="flex items-start">
                  <i className="fa-solid fa-check-circle text-green-500 mt-1 mr-2"></i>
                  <span>抗台风设计：支架强度符合越南台风等级标准，增加支架拉杆、斜撑</span>
                </li>
              </ul>
            </div>
            
            <div className="bg-white dark:bg-gray-800 p-6 rounded-xl shadow-lg border border-gray-100 dark:border-gray-700">
              <h4 className="text-lg font-semibold text-gray-800 dark:text-white mb-4 flex items-center">
                <i className="fa-solid fa-building text-green-600 dark:text-green-400 mr-2"></i>
                混凝土屋面支架
              </h4>
              <ul className="space-y-3 text-gray-600 dark:text-gray-300">
                <li className="flex items-start">
                  <i className="fa-solid fa-check-circle text-green-500 mt-1 mr-2"></i>
                  <span>材质：热镀锌钢制支架（Q235B），承重能力强、耐久性好</span>
                </li>
                <li className="flex items-start">
                  <i className="fa-solid fa-check-circle text-green-500 mt-1 mr-2"></i>
                  <span>固定方式：采用膨胀螺栓固定，螺栓植入混凝土屋面深度≥100mm</span>
                </li>
                <li className="flex items-start">
                  <i className="fa-solid fa-check-circle text-green-500 mt-1 mr-2"></i>
                  <span>防腐处理：支架表面采用热镀锌工艺，镀锌层厚度≥80μm</span>
                </li>
              </ul>
            </div>
          </div>
          
          {/* 支架系统图示 */}
          <div className="mt-8 grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="relative h-64 bg-gray-100 dark:bg-gray-700 rounded-lg flex items-center justify-center overflow-hidden">
              <img 
                src="https://space.coze.cn/api/coze_space/gen_image?image_size=landscape_4_3&prompt=Aluminum%20solar%20panel%20mounting%20system%20on%20metal%20roof%2C%20closeup%20view&sign=9f96d654dec298e4fa6dff240a7a768e" 
                alt="彩钢瓦屋面支架" 
                className="w-full h-full object-cover"
              />
              <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/60 to-transparent p-4">
                <p className="text-white text-center text-sm">彩钢瓦屋面铝合金支架</p>
              </div>
            </div>
            
            <div className="relative h-64 bg-gray-100 dark:bg-gray-700 rounded-lg flex items-center justify-center overflow-hidden">
              <img 
                src="https://space.coze.cn/api/coze_space/gen_image?image_size=landscape_4_3&prompt=Steel%20solar%20panel%20mounting%20system%20on%20concrete%20roof%2C%20closeup%20view&sign=b5335581ab05054be629bbb06709ea7a" 
                alt="混凝土屋面支架" 
                className="w-full h-full object-cover"
              />
              <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/60 to-transparent p-4">
                <p className="text-white text-center text-sm">混凝土屋面热镀锌钢支架</p>
              </div>
            </div>
          </div>
        </motion.div>
        
        {/* 其他设计内容可以根据需要继续添加 */}
        <motion.div
          className="grid grid-cols-1 md:grid-cols-2 gap-8"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
        >
          <div className="bg-white dark:bg-gray-800 p-6 rounded-xl shadow-lg border border-gray-100 dark:border-gray-700">
            <div className="flex items-center mb-4">
              <div className="w-10 h-10 bg-blue-100 dark:bg-blue-900/30 rounded-lg flex items-center justify-center mr-3">
                <i className="fa-solid fa-plug-circle-bolt text-blue-600 dark:text-blue-400"></i>
              </div>
              <h3 className="text-xl font-semibold text-gray-800 dark:text-white">{t('design.inverter')}</h3>
            </div>
            <p className="text-gray-600 dark:text-gray-300 mb-4">
              逆变器作为"光伏电站心脏"，需适配高温环境、提升转换效率，选用组串式逆变器（转换效率≥98.5%），防护等级≥IP65。
            </p>
            <motion.button
              className="mt-4 py-2 px-4 bg-blue-600 text-white font-medium rounded-lg shadow-md hover:bg-blue-700 transition-colors"
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.98 }}
            >
              {t('read.more')}
            </motion.button>
          </div>
          
          <div className="bg-white dark:bg-gray-800 p-6 rounded-xl shadow-lg border border-gray-100 dark:border-gray-700">
            <div className="flex items-center mb-4">
              <div className="w-10 h-10 bg-green-100 dark:bg-green-900/30 rounded-lg flex items-center justify-center mr-3">
                <i className="fa-solid fa-tint-slash text-green-600 dark:text-green-400"></i>
              </div>
              <h3 className="text-xl font-semibold text-gray-800 dark:text-white">{t('design.waterproof')}</h3>
            </div>
            <p className="text-gray-600 dark:text-gray-300 mb-4">
              结合越南高温、多雨、高湿度环境，重点强化防水、防腐设计，避免电站运行过程中出现屋顶渗漏、设备腐蚀等问题。
            </p>
            <motion.button
              className="mt-4 py-2 px-4 bg-green-600 text-white font-medium rounded-lg shadow-md hover:bg-green-700 transition-colors"
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.98 }}
            >
              {t('read.more')}
            </motion.button>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
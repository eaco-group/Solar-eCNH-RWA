import { useLanguage } from '../contexts/languageContext';
import { motion } from 'framer-motion';

export function ECNHSection() {
  const { t } = useLanguage();
  
  // eCNH RWA核心环节数据
  const ecnhCoreSteps = [
    {
      title: t('ecnh.asset'),
      icon: 'fa-shield-halved',
      description: '确保项目资产权属清晰、可量化、可追溯，办理相关确权手续，委托专业机构对资产进行评估。',
      color: 'blue'
    },
    {
      title: t('ecnh.financing'),
      icon: 'fa-hand-holding-dollar',
      description: '以项目eCNH RWA资产为底层支撑，发行eCNH计价的资产支持证券，引入境外离岸人民币资金。',
      color: 'green'
    },
    {
      title: t('ecnh.settlement'),
      icon: 'fa-exchange-alt',
      description: '项目收益均以eCNH计价结算，与境外投资者、EVN协商，建立eCNH结算通道，确保收益及时回款。',
      color: 'purple'
    },
    {
      title: t('ecnh.risk'),
      icon: 'fa-shield-alt',
      description: '建立全方位的风险管控体系，保障eCNH RWA模式可持续运行，保护投资者权益。',
      color: 'orange'
    },
    {
      title: t('ecnh.optimization'),
      icon: 'fa-chart-line',
      description: '在项目推进过程中逐步优化完善eCNH RWA模式，形成可复制、可推广的应用方案。',
      color: 'red'
    }
  ];
  
  // eCNH RWA应用优势
  const ecnhBenefits = [
    {
      title: '简化跨境投融资流程',
      description: '利用eCNH数字化结算优势，简化融资审批流程，缩短融资周期',
      icon: 'fa-bolt'
    },
    {
      title: '规避汇率波动风险',
      description: '通过eCNH计价结算，规避越南盾与人民币、美元之间的汇率波动风险',
      icon: 'fa-chart-area'
    },
    {
      title: '提升收益稳定性',
      description: '确保项目收益、投资者回报稳定，便于境外投资者收益回款',
      icon: 'fa-check-circle'
    },
    {
      title: '降低融资成本',
      description: '依托eCNH RWA资产的稳定性、可追溯性，提升项目信用评级，降低融资利率',
      icon: 'fa-money-bill-wave'
    }
  ];
  
  // eCNH相关链接
  const ecnhLinks = [
    { name: 'Dexscreener', url: 'https://dexscreener.com/solana/7GQnqthWKa5v2GqXYWhmgWZY5mCRrniwK3Xuinm9GKw5' },
    { name: 'Solscan', url: 'https://solscan.io/token/7GQnqthWKa5v2GqXYWhmgWZY5mCRrniwK3Xuinm9GKw5' },
    { name: 'OKLink', url: 'https://www.oklink.com/solana/token/7GQnqthWKa5v2GqXYWhmgWZY5mCRrniwK3Xuinm9GKw5' },
    { name: 'OKX Web3', url: 'https://web3.okx.com/token/solana/7GQnqthWKa5v2GqXYWhmgWZY5mCRrniwK3Xuinm9GKw5' },
    { name: 'Twitter', url: 'https://x.com/earthCNH' },
    { name: 'Telegram', url: 'https://t.me/eCNHusdc' }
  ];
  
  return (
    <section id="ecnh" className="py-20 bg-gradient-to-br from-blue-600 to-purple-700 text-white">
      <div className="container mx-auto px-4">
        <motion.div
          className="text-center mb-16"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
        >
          <h2 className="text-3xl font-bold mb-4">{t('ecnh.section')}</h2>
          <div className="w-20 h-1 bg-white mx-auto rounded-full"></div>
        </motion.div>
        
        {/* eCNH RWA核心流程 */}
        <motion.div
          className="mb-16"
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
        >
          <div className="grid grid-cols-1 md:grid-cols-5 gap-6">
            {ecnhCoreSteps.map((step, index) => (
              <motion.div
                key={index}
                className={`bg-white/10 backdrop-blur-md p-6 rounded-xl border border-white/20`}
                whileHover={{ y: -10, backgroundColor: 'rgba(255, 255, 255, 0.15)' }}
                transition={{ duration: 0.3 }}
              >
                <div className={`w-14 h-14 bg-${step.color}-500/20 rounded-full flex items-center justify-center mb-4 border border-${step.color}-400/30`}>
                  <i className={`fa-solid ${step.icon} text-white text-2xl`}></i>
                </div>
                <h3 className="text-xl font-semibold mb-3">{step.title}</h3>
                <p className="text-white/80 text-sm">{step.description}</p>
                
                {/* 连接线 */}
                {index < ecnhCoreSteps.length - 1 && (
                  <div className="hidden md:block absolute top-1/2 -right-8 transform -translate-y-1/2 z-10">
                    <svg width="30" height="30" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                      <path d="M5 12H19M19 12L12 5M19 12L12 19" stroke="rgba(255,255,255,0.6)" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                    </svg>
                  </div>
                )}
              </motion.div>
            ))}
          </div>
        </motion.div>
        
        {/* eCNH RWA应用优势 */}
        <motion.div
          className="mb-16"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
        >
          <h3 className="text-2xl font-bold mb-8 text-center">eCNH RWA模式应用优势</h3>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {ecnhBenefits.map((benefit, index) => (
              <motion.div
                key={index}
                className="bg-white/10 backdrop-blur-md p-6 rounded-xl border border-white/20"
                whileHover={{ scale: 1.05 }}
                transition={{ duration: 0.3 }}
              >
                <div className="w-12 h-12 bg-white/20 rounded-lg flex items-center justify-center mb-4">
                  <i className={`fa-solid ${benefit.icon} text-white text-xl`}></i>
                </div>
                <h4 className="text-lg font-semibold mb-2">{benefit.title}</h4>
                <p className="text-white/80 text-sm">{benefit.description}</p>
              </motion.div>
            ))}
          </div>
        </motion.div>
        
        {/* eCNH相关信息 */}
        <motion.div
          className="bg-white/10 backdrop-blur-md p-8 rounded-2xl border border-white/20"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
        >
          <div className="flex flex-col md:flex-row md:items-center justify-between mb-8">
            <div>
              <h3 className="text-2xl font-bold mb-2">eCNH CA</h3>
              <p className="text-white/80">7GQnqthWKa5v2GqXYWhmgWZY5mCRrniwK3Xuinm9GKw5</p>
            </div>
            
            <div className="mt-4 md:mt-0">
              <motion.button
                className="bg-white text-blue-600 font-medium px-6 py-2 rounded-lg shadow-lg hover:bg-opacity-90 transition-all"
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.98 }}
              >
                <i className="fa-solid fa-copy mr-2"></i>复制地址
              </motion.button>
            </div>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-6 gap-4">
            {ecnhLinks.map((link, index) => (
              <motion.a
                key={index}
                href={link.url}
                target="_blank"
                rel="noopener noreferrer"
                className="bg-white/5 hover:bg-white/10 text-white/80 hover:text-white p-3 rounded-lg text-center text-sm transition-colors"
                whileHover={{ y: -3 }}
                transition={{ duration: 0.3 }}
              >
                {link.name}
              </motion.a>
            ))}
          </div>
        </motion.div>
        
        {/* eCNH钱包推荐 */}
        <motion.div
          className="mt-8 text-center"
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          transition={{ duration: 0.8, delay: 0.2 }}
          viewport={{ once: true }}
        >
          <p className="text-white/80">只要钱包支持 Solana 链，就能支持 eCNH；推荐使用 Phantom、Solflare、OKX Web3 等作为主钱包。</p>
        </motion.div>
      </div>
    </section>
  );
}
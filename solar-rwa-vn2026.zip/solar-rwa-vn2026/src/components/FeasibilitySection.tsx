import { useLanguage } from '../contexts/languageContext';
import { motion } from 'framer-motion';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, AreaChart, Area } from 'recharts';

// 投资回报数据
const roiData = [
  { year: '第1年', revenue: 50, cost: 120 },
  { year: '第2年', revenue: 80, cost: 20 },
  { year: '第3年', revenue: 85, cost: 20 },
  { year: '第4年', revenue: 90, cost: 20 },
  { year: '第5年', revenue: 95, cost: 20 },
  { year: '第6年', revenue: 100, cost: 20 },
  { year: '第7年', revenue: 105, cost: 20 },
  { year: '第8年', revenue: 100, cost: 20 },
  { year: '第9年', revenue: 95, cost: 20 },
  { year: '第10年', revenue: 90, cost: 20 },
];

// 技术成熟度数据
const maturityData = [
  { name: '光伏组件', value: 95 },
  { name: '逆变器', value: 90 },
  { name: '支架系统', value: 85 },
  { name: '并网技术', value: 88 },
  { name: '监控系统', value: 92 },
];

// 项目风险评估数据
const riskData = [
  { name: '政策风险', low: 30, medium: 50, high: 20 },
  { name: '技术风险', low: 60, medium: 30, high: 10 },
  { name: '环境风险', low: 40, medium: 45, high: 15 },
  { name: '市场风险', low: 50, medium: 40, high: 10 },
  { name: '融资风险', low: 45, medium: 40, high: 15 },
];

export function FeasibilitySection() {
  const { t } = useLanguage();
  
  return (
    <section id="feasibility" className="py-20 bg-gray-50 dark:bg-gray-850">
      <div className="container mx-auto px-4">
        <motion.div
          className="text-center mb-16"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
        >
          <h2 className="text-3xl font-bold text-gray-900 dark:text-white mb-4">{t('feasibility.section')}</h2>
          <div className="w-20 h-1 bg-gradient-to-r from-blue-500 to-green-500 mx-auto rounded-full"></div>
        </motion.div>
        
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-12">
          {/* 技术可行性 */}
          <motion.div
            className="bg-white dark:bg-gray-800 p-8 rounded-2xl shadow-xl border border-gray-100 dark:border-gray-700"
            initial={{ opacity: 0, x: -20 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
          >
            <div className="flex items-center mb-6">
              <div className="w-12 h-12 bg-blue-100 dark:bg-blue-900/30 rounded-lg flex items-center justify-center mr-4">
                <i className="fa-solid fa-gear text-blue-600 dark:text-blue-400 text-xl"></i>
              </div>
              <h3 className="text-xl font-bold text-gray-900 dark:text-white">{t('feasibility.technical')}</h3>
            </div>
            
            <ul className="space-y-4 text-gray-600 dark:text-gray-300 mb-6">
              <li className="flex items-start">
                <i className="fa-solid fa-check-circle text-green-500 mt-1 mr-2"></i>
                <span>屋顶承重可行性：通过专业检测机构分区核算承重，采用轻型支架、分散布局优化</span>
              </li>
              <li className="flex items-start">
                <i className="fa-solid fa-check-circle text-green-500 mt-1 mr-2"></i>
                <span>并网可行性：可申请专用并网接入点，结合"自发自用、余电上网"模式，高效消纳</span>
              </li>
              <li className="flex items-start">
                <i className="fa-solid fa-check-circle text-green-500 mt-1 mr-2"></i>
                <span>设备适配可行性：光伏核心设备能适配越南高温、高湿度、台风环境</span>
              </li>
            </ul>
            
            <div className="h-64">
              <p className="text-sm font-medium text-gray-500 dark:text-gray-400 mb-2">光伏技术成熟度评估</p>
              <ResponsiveContainer width="100%" height="90%">
                <AreaChart data={maturityData}>
                  <defs>
                    <linearGradient id="maturityColor" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.8}/>
                      <stop offset="95%" stopColor="#3b82f6" stopOpacity={0.1}/>
                    </linearGradient>
                  </defs>
                  <XAxis dataKey="name" />
                  <YAxis domain={[0, 100]} />
                  <CartesianGrid strokeDasharray="3 3" />
                  <Tooltip />
                  <Area type="monotone" dataKey="value" stroke="#3b82f6" fillOpacity={1} fill="url(#maturityColor)" name="成熟度(%)" />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </motion.div>
          
          {/* 经济可行性 */}
          <motion.div
            className="bg-white dark:bg-gray-800 p-8 rounded-2xl shadow-xl border border-gray-100 dark:border-gray-700"
            initial={{ opacity: 0, x: 20 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
          >
            <div className="flex items-center mb-6">
              <div className="w-12 h-12 bg-green-100 dark:bg-green-900/30 rounded-lg flex items-center justify-center mr-4">
                <i className="fa-solid fa-chart-line text-green-600 dark:text-green-400 text-xl"></i>
              </div>
              <h3 className="text-xl font-bold text-gray-900 dark:text-white">{t('feasibility.economic')}</h3>
            </div>
            
            <h4 className="font-semibold text-gray-800 dark:text-white mb-3">投资成本</h4>
            <p className="text-gray-600 dark:text-gray-300 mb-4">
              总投资约48-64亿元人民币（含设备采购、设计、施工、并网、运维），单位投资成本约7-8元/W。
            </p>
            
            <h4 className="font-semibold text-gray-800 dark:text-white mb-3">收益来源</h4>
            <ul className="space-y-2 text-gray-600 dark:text-gray-300 mb-6">
              <li className="flex items-start">
                <i className="fa-solid fa-check-circle text-green-500 mt-1 mr-2"></i>
                <span>自发自用节省的工商业电费</span>
              </li>
              <li className="flex items-start">
                <i className="fa-solid fa-check-circle text-green-500 mt-1 mr-2"></i>
                <span>余电上网电费收入</span>
              </li>
              <li className="flex items-start">
                <i className="fa-solid fa-check-circle text-green-500 mt-1 mr-2"></i>
                <span>政府补贴（如符合条件）</span>
              </li>
              <li className="flex items-start">
                <i className="fa-solid fa-check-circle text-green-500 mt-1 mr-2"></i>
                <span>节能减排带来的碳收益</span>
              </li>
              <li className="flex items-start">
                <i className="fa-solid fa-check-circle text-green-500 mt-1 mr-2"></i>
                <span>eCNH RWA资产增值收益</span>
              </li>
            </ul>
            
            <div className="h-64">
              <p className="text-sm font-medium text-gray-500 dark:text-gray-400 mb-2">项目投资回报分析（单位：百万元）</p>
              <ResponsiveContainer width="100%" height="90%">
                <LineChart data={roiData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="year" />
                  <YAxis />
                  <Tooltip />
                  <Legend />
                  <Line type="monotone" dataKey="revenue" stroke="#4ade80" name="收入" strokeWidth={2} />
                  <Line type="monotone" dataKey="cost" stroke="#ef4444" name="成本" strokeWidth={2} />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </motion.div>
        </div>
        
        {/* 合规可行性 */}
        <motion.div
          className="bg-white dark:bg-gray-800 p-8 rounded-2xl shadow-xl border border-gray-100 dark:border-gray-700"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
        >
          <div className="flex items-center mb-6">
            <div className="w-12 h-12 bg-purple-100 dark:bg-purple-900/30 rounded-lg flex items-center justify-center mr-4">
              <i className="fa-solid fa-scale-balanced text-purple-600 dark:text-purple-400 text-xl"></i>
            </div>
            <h3 className="text-xl font-bold text-gray-900 dark:text-white">{t('feasibility.compliance')}</h3>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div>
              <h4 className="font-semibold text-gray-800 dark:text-white mb-3">项目合规</h4>
              <ul className="space-y-2 text-gray-600 dark:text-gray-300">
                <li className="flex items-start">
                  <i className="fa-solid fa-check-circle text-green-500 mt-1 mr-2"></i>
                  <span>向当地能源部门申请项目备案</span>
                </li>
                <li className="flex items-start">
                  <i className="fa-solid fa-check-circle text-green-500 mt-1 mr-2"></i>
                  <span>向EVN申请并网许可</span>
                </li>
                <li className="flex items-start">
                  <i className="fa-solid fa-check-circle text-green-500 mt-1 mr-2"></i>
                  <span>符合越南国家标准及国际标准</span>
                </li>
              </ul>
            </div>
            
            <div>
              <h4 className="font-semibold text-gray-800 dark:text-white mb-3">产权合规</h4>
              <ul className="space-y-2 text-gray-600 dark:text-gray-300">
                <li className="flex items-start">
                  <i className="fa-solid fa-check-circle text-green-500 mt-1 mr-2"></i>
                  <span>确认厂房产权归属</span>
                </li>
                <li className="flex items-start">
                  <i className="fa-solid fa-check-circle text-green-500 mt-1 mr-2"></i>
                  <span>签订屋顶使用协议（若需）</span>
                </li>
                <li className="flex items-start">
                  <i className="fa-solid fa-check-circle text-green-500 mt-1 mr-2"></i>
                  <span>明确双方权利义务</span>
                </li>
              </ul>
            </div>
            
            <div>
              <h4 className="font-semibold text-gray-800 dark:text-white mb-3">eCNH RWA合规</h4>
              <ul className="space-y-2 text-gray-600 dark:text-gray-300">
                <li className="flex items-start">
                  <i className="fa-solid fa-check-circle text-green-500 mt-1 mr-2"></i>
                  <span>符合跨境资金监管政策</span>
                </li>
                <li className="flex items-start">
                  <i className="fa-solid fa-check-circle text-green-500 mt-1 mr-2"></i>
                  <span>明确eCNH资金的投资范围</span>
                </li>
                <li className="flex items-start">
                  <i className="fa-solid fa-check-circle text-green-500 mt-1 mr-2"></i>
                  <span>建立完善的资产估值体系</span>
                </li>
              </ul>
            </div>
          </div>
          
          <div className="mt-8 h-64">
            <p className="text-sm font-medium text-gray-500 dark:text-gray-400 mb-2">项目风险评估</p>
            <ResponsiveContainer width="100%" height="90%">
              <AreaChart data={riskData} stackOffset="expand">
                <XAxis dataKey="name" />
                <YAxis tickFormatter={(tick) => `${tick * 100}%`} />
                <CartesianGrid strokeDasharray="3 3" />
                <Tooltip formatter={(value) => `${(value * 100).toFixed(0)}%`} />
                <Legend />
                <Area type="monotone" dataKey="low" stackId="1" stroke="#4ade80" fill="#4ade80" name="低风险" />
                <Area type="monotone" dataKey="medium" stackId="1" stroke="#f59e0b" fill="#f59e0b" name="中风险" />
                <Area type="monotone" dataKey="high" stackId="1" stroke="#ef4444" fill="#ef4444" name="高风险" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
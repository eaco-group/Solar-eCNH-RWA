import { useLanguage } from '../contexts/languageContext';
import { motion } from 'framer-motion';

export function Footer() {
  const { t } = useLanguage();
  
  // 联系信息
  const contactInfo = [
    { icon: 'fa-envelope', text: 'eaco2cc@gmail.com' },
    { icon: 'fa-map-marker-alt', text: '越南友谊关口岸' },
    { icon: 'fa-map-marker-alt', text: '越南老街口岸' },
    { icon: 'fa-map-marker-alt', text: '越南芒街口岸' },
    { icon: 'fa-map-marker-alt', text: '越南茶岭口岸' }
  ];
  
  // 社交媒体链接
  const socialLinks = [
    { icon: 'fa-facebook-f', url: '#' },
    { icon: 'fa-twitter', url: '#' },
    { icon: 'fa-linkedin-in', url: '#' },
    { icon: 'fa-instagram', url: '#' },
    { icon: 'fa-youtube', url: '#' }
  ];
  
  // 快速链接
  const quickLinks = [
    { text: t('navbar.home'), url: '/' },
    { text: t('navbar.overview'), url: '#overview' },
    { text: t('navbar.feasibility'), url: '#feasibility' },
    { text: t('navbar.design'), url: '#design' },
    { text: t('navbar.ecnh'), url: '#ecnh' },
    { text: t('navbar.risk'), url: '#risk' },
    { text: t('navbar.implementation'), url: '#implementation' }
  ];
  
  return (
    <footer className="bg-gray-900 text-white pt-16 pb-8">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-12">
          {/* 公司信息 */}
          <div>
            <div className="flex items-center space-x-2 mb-6">
              <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-green-400 to-blue-500 flex items-center justify-center">
                <i className="fa-solid fa-solar-system text-white text-xl"></i>
              </div>
              <div>
                <h2 className="text-lg font-bold">{t('site.title')}</h2>
                <p className="text-xs text-gray-400">{t('site.subtitle')}</p>
              </div>
            </div>
            <p className="text-gray-400 mb-6 text-sm">
              探索工业厂房分布式光伏电站与离岸人民币真实世界资产的创新结合，为跨境光伏项目的投融资、收益结算提供新路径。
            </p>
            <div className="flex space-x-4">
              {socialLinks.map((link, index) => (
                <motion.a
                  key={index}
                  href={link.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-10 h-10 rounded-full bg-gray-800 flex items-center justify-center hover:bg-blue-600 transition-colors"
                  whileHover={{ scale: 1.1, rotate: 5 }}
                  transition={{ duration: 0.2 }}
                >
                  <i className={`fa-brands ${link.icon}`}></i>
                </motion.a>
              ))}
            </div>
          </div>
          
          {/* 快速链接 */}
          <div>
            <h3 className="text-lg font-semibold mb-6">快速链接</h3>
            <ul className="space-y-3">
              {quickLinks.map((link, index) => (
                <li key={index}>
                  <a href={link.url} className="text-gray-400 hover:text-white transition-colors text-sm">
                    <i className="fa-solid fa-chevron-right text-xs mr-2"></i>
                    {link.text}
                  </a>
                </li>
              ))}
            </ul>
          </div>
          
          {/* 联系信息 */}
          <div>
            <h3 className="text-lg font-semibold mb-6">联系我们</h3>
            <ul className="space-y-4">
              {contactInfo.map((info, index) => (
                <li key={index} className="flex items-start">
                  <div className="w-10 h-10 rounded-full bg-gray-800 flex items-center justify-center mr-3 flex-shrink-0">
                    <i className={`fa-solid ${info.icon}`}></i>
                  </div>
                  <span className="text-gray-400 text-sm">{info.text}</span>
                </li>
              ))}
            </ul>
          </div>
          
          {/* eCNH CA信息 */}
          <div>
            <h3 className="text-lg font-semibold mb-6">eCNH CA</h3>
            <div className="bg-gray-800 p-4 rounded-lg mb-6">
              <p className="text-gray-400 text-sm font-mono break-all">
                7GQnqthWKa5v2GqXYWhmgWZY5mCRrniwK3Xuinm9GKw5
              </p>
            </div>
            <motion.button
              className="w-full py-2 bg-blue-600 text-white font-medium rounded-lg shadow-md hover:bg-blue-700 transition-colors text-sm"
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
            >
              <i className="fa-solid fa-copy mr-2"></i>复制地址
            </motion.button>
          </div>
        </div>
        
        {/* 底部版权信息 */}
        <div className="pt-8 border-t border-gray-800 text-center text-gray-500 text-sm">
          <p>© 2026 光伏结合eCNH RWA项目. 保留所有权利.</p>
        </div>
      </div>
    </footer>
  );
}
import { useState } from 'react';
import { useLanguage, languageNames, Language } from '../contexts/languageContext';
import { motion } from 'framer-motion';

export function Header() {
  const { language, setLanguage, t } = useLanguage();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  
  // 导航链接数据
  const navLinks = [
    { key: 'navbar.home', href: '/' },
    { key: 'navbar.overview', href: '#overview' },
    { key: 'navbar.feasibility', href: '#feasibility' },
    { key: 'navbar.design', href: '#design' },
    { key: 'navbar.ecnh', href: '#ecnh' },
    { key: 'navbar.risk', href: '#risk' },
    { key: 'navbar.implementation', href: '#implementation' }
  ];
  
  // 关闭移动菜单
  const closeMobileMenu = () => {
    setMobileMenuOpen(false);
  };
  
  return (
    <motion.header 
      className="fixed top-0 left-0 right-0 bg-white/80 dark:bg-gray-900/80 backdrop-blur-md z-50 shadow-sm"
      initial={{ opacity: 0, y: -20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
    >
      <div className="container mx-auto px-4 py-4">
        <div className="flex justify-between items-center">
          {/* Logo 和网站标题 */}
          <div className="flex items-center space-x-2">
            <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-green-400 to-blue-500 flex items-center justify-center">
              <i className="fa-solid fa-solar-system text-white text-xl"></i>
            </div>
            <div>
              <h1 className="text-lg font-bold text-gray-800 dark:text-white">{t('site.title')}</h1>
              <p className="text-xs text-gray-500 dark:text-gray-400">{t('site.subtitle')}</p>
            </div>
          </div>
          
          {/* 桌面导航 */}
          <nav className="hidden md:flex items-center space-x-6">
            {navLinks.map((link) => (
              <a 
                key={link.key}
                href={link.href}
                className="text-sm font-medium text-gray-600 dark:text-gray-300 hover:text-blue-500 dark:hover:text-blue-400 transition-colors"
                onClick={closeMobileMenu}
              >
                {t(link.key)}
              </a>
            ))}
            
            {/* 语言选择器 */}
            <div className="relative group">
              <button className="flex items-center space-x-1 text-sm font-medium text-gray-600 dark:text-gray-300">
                <span>{languageNames[language]}</span>
                <i className="fa-solid fa-chevron-down text-xs"></i>
              </button>
              <div className="absolute right-0 mt-2 w-40 rounded-lg shadow-lg bg-white dark:bg-gray-800 ring-1 ring-black ring-opacity-5 opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all duration-300 z-50">
                <div className="py-1">
                  {Object.entries(languageNames).map(([code, name]) => (
                    <button
                      key={code}
                      onClick={() => setLanguage(code as Language)}
                      className={`block w-full text-left px-4 py-2 text-sm ${language === code ? 'bg-blue-50 dark:bg-blue-900/30 text-blue-600 dark:text-blue-400' : 'text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700'}`}
                    >
                      {name}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </nav>
          
          {/* 移动端菜单按钮 */}
          <button 
            className="md:hidden text-gray-600 dark:text-gray-300"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          >
            <i className={`fa-solid ${mobileMenuOpen ? 'fa-xmark' : 'fa-bars'} text-xl`}></i>
          </button>
        </div>
        
        {/* 移动端菜单 */}
        {mobileMenuOpen && (
          <motion.div
            className="md:hidden mt-4 py-4 border-t border-gray-200 dark:border-gray-700"
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            transition={{ duration: 0.3 }}
          >
            <div className="space-y-4">
              {navLinks.map((link) => (
                <a 
                  key={link.key}
                  href={link.href}
                  className="block text-gray-600 dark:text-gray-300 hover:text-blue-500 dark:hover:text-blue-400 py-2"
                  onClick={closeMobileMenu}
                >
                  {t(link.key)}
                </a>
              ))}
              
              {/* 移动端语言选择器 */}
              <div className="pt-2">
                <p className="text-sm text-gray-500 dark:text-gray-400 mb-2">选择语言 / Select Language</p>
                <div className="grid grid-cols-2 gap-2">
                  {Object.entries(languageNames).map(([code, name]) => (
                    <button
                      key={code}
                      onClick={() => {
                        setLanguage(code as Language);
                        closeMobileMenu();
                      }}
                      className={`px-4 py-2 text-sm rounded ${language === code ? 'bg-blue-50 dark:bg-blue-900/30 text-blue-600 dark:text-blue-400' : 'bg-gray-100 dark:bg-gray-800 text-gray-700 dark:text-gray-300'}`}
                    >
                      {name}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </motion.div>
        )}
      </div>
    </motion.header>
  );
}
import { useLanguage } from '../contexts/languageContext';
import { motion } from 'framer-motion';

export function HeroSection() {
  const { t } = useLanguage();
  
  return (
    <section className="relative pt-28 pb-20 md:pt-40 md:pb-32 overflow-hidden">
      {/* 背景装饰 */}
      <div className="absolute inset-0 bg-gradient-to-br from-blue-50 to-green-50 dark:from-gray-900 dark:to-gray-800 z-0"></div>
      <div className="absolute top-0 right-0 w-full h-full opacity-10 z-0">
        <div className="absolute top-1/4 left-1/4 w-96 h-96 rounded-full bg-blue-400 blur-3xl"></div>
        <div className="absolute bottom-1/4 right-1/4 w-96 h-96 rounded-full bg-green-400 blur-3xl"></div>
      </div>
      
      <div className="container mx-auto px-4 relative z-10">
        <motion.div
          className="max-w-4xl mx-auto text-center"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
        >
          <h1 className="text-3xl md:text-5xl font-bold text-gray-900 dark:text-white mb-6">
            {t('hero.title')}
          </h1>
          <h2 className="text-xl md:text-2xl font-semibold text-blue-600 dark:text-blue-400 mb-8">
            {t('hero.subtitle')}
          </h2>
          <p className="text-lg text-gray-600 dark:text-gray-300 mb-10 max-w-3xl mx-auto">
            {t('hero.description')}
          </p>
          
          <div className="flex flex-col sm:flex-row justify-center gap-4">
            <motion.a
              href="#overview"
              className="inline-flex items-center justify-center px-6 py-3 bg-gradient-to-r from-blue-600 to-green-500 text-white font-medium rounded-lg shadow-lg hover:shadow-xl transition-all duration-300"
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.98 }}
            >
              <span>{t('learn.more')}</span>
              <i className="fa-solid fa-arrow-right ml-2"></i>
            </motion.a>
            
            <motion.a
              href="#ecnh"
              className="inline-flex items-center justify-center px-6 py-3 bg-white dark:bg-gray-800 text-blue-600 dark:text-blue-400 font-medium rounded-lg shadow-md hover:shadow-lg transition-all duration-300 border border-gray-200 dark:border-gray-700"
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.98 }}
            >
              <i className="fa-solid fa-rocket mr-2"></i>
              <span>{t('navbar.ecnh')}</span>
            </motion.a>
          </div>
        </motion.div>
        
        {/* 数据卡片 */}
        <motion.div
          className="mt-16 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6"
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.3 }}
        >
          {[
            { icon: 'fa-building', text: t('factory.area') },
            { icon: 'fa-percent', text: t('factory.utilization') },
            { icon: 'fa-bolt', text: t('factory.capacity') },
            { icon: 'fa-calendar-check', text: t('factory.payback') }
          ].map((item, index) => (
            <motion.div
              key={index}
              className="bg-white dark:bg-gray-800 p-6 rounded-xl shadow-lg border border-gray-100 dark:border-gray-700"
              whileHover={{ y: -5 }}
            >
              <div className="w-12 h-12 bg-blue-100 dark:bg-blue-900/30 rounded-lg flex items-center justify-center mb-4">
                <i className={`fa-solid ${item.icon} text-blue-600 dark:text-blue-400 text-xl`}></i>
              </div>
              <p className="text-lg font-medium text-gray-800 dark:text-white">{item.text}</p>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  );
}
import { useLanguage } from '../contexts/languageContext';
import { motion } from 'framer-motion';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';

// 项目实施计划数据（用于BarChart）
const implementationData = [
  { name: '前期筹备阶段', duration: 3, color: '#3b82f6' },
  { name: '设备采购与运输', duration: 3, color: '#4ade80' },
  { name: '现场施工阶段', duration: 8, color: '#f59e0b' },
  { name: '调试与并网阶段', duration: 2, color: '#8b5cf6' },
  { name: '运维交接与推广', duration: 1, color: '#ec4899' },
];

// 实施阶段详细内容
const implementationPhases = [
  {
    phase: '前期筹备阶段 (2-3个月)',
    details: [
      '完成厂房屋顶分区检测、太阳辐照量监测、用电负荷调研',
      '核实当地政策（光伏政策、跨境资金政策），办理项目备案、并网许可等审批手续',
      '完成方案优化设计、设备选型及采购招标，确定设备供应商及eCNH RWA服务机构',
      '签订设备采购合同、施工合同、屋顶使用协议、eCNH RWA服务协议等'
    ],
    icon: 'fa-clipboard-list',
    color: 'blue'
  },
  {
    phase: '设备采购与运输阶段 (2-3个月)',
    details: [
      '跟进设备生产进度，确保设备按时交付',
      '办理设备进口手续，安排运输，确保设备安全送达项目现场',
      '利用eCNH跨境结算优势，完成设备采购资金结算',
      '完成设备进场验收、仓储管理，建立设备台账'
    ],
    icon: 'fa-truck-loading',
    color: 'green'
  },
  {
    phase: '现场施工阶段 (6-8个月)',
    details: [
      '完成屋顶加固、防水处理（若需），分区施工，确保施工质量',
      '进行支架安装、组件排布及固定，部分区域安装跟踪系统',
      '完成逆变器、汇流箱、配电柜等设备安装及线缆敷设',
      '搭建智能监控系统，确保数据实时监测、上传'
    ],
    icon: 'fa-hard-hat',
    color: 'orange'
  },
  {
    phase: '调试与并网阶段 (1-2个月)',
    details: [
      '完成电站设备调试、系统联调，重点调试智能监控系统',
      '向EVN提交并网验收申请，配合完成并网验收',
      '试点区域优先完成并网，启动eCNH RWA试点运行',
      '完成电站并网，正式投入试运行'
    ],
    icon: 'fa-plug-circle-check',
    color: 'purple'
  },
  {
    phase: '运维交接与eCNH RWA推广阶段 (1个月)',
    details: [
      '完成运维人员培训、备件交接，建立完善的运维管理制度',
      '签订运维协议，正式移交运维工作',
      '总结eCNH RWA试点经验，优化模式应用流程',
      '完成eCNH RWA资产全面备案、登记，启动全项目eCNH RWA工作'
    ],
    icon: 'fa-handshake',
    color: 'red'
  }
];

export function ImplementationSection() {
  const { t } = useLanguage();
  
  return (
    <section id="implementation" className="py-20 bg-white dark:bg-gray-900">
      <div className="container mx-auto px-4">
        <motion.div
          className="text-center mb-16"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
        >
          <h2 className="text-3xl font-bold text-gray-900 dark:text-white mb-4">{t('implementation.section')}</h2>
          <div className="w-20 h-1 bg-gradient-to-r from-blue-500 to-green-500 mx-auto rounded-full"></div>
          <p className="mt-4 text-gray-600 dark:text-gray-300 max-w-2xl mx-auto">
            结合项目大型化规模、越南当地实际情况及eCNH RWA模式应用需求，制定分阶段实施计划，确保项目有序推进，预估总工期约12-16个月
          </p>
        </motion.div>
        
        {/* 甘特图 */}
        <motion.div
          className="mb-16 bg-white dark:bg-gray-800 p-6 rounded-2xl shadow-xl border border-gray-100 dark:border-gray-700"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
        >
          <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-6">项目进度甘特图</h3>
           <div className="h-96">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart
                  data={implementationData}
                  margin={{ top: 20, right: 30, left: 20, bottom: 20 }}
                  layout="vertical"
                >
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis type="number" domain={[0, 12]} label={{ value: '持续时间(月)', position: 'insideBottomRight', offset: -10 }} />
                  <YAxis dataKey="name" type="category" width={120} />
                  <Tooltip formatter={(value) => [`${value} 个月`, '持续时间']} />
                  <Legend />
                  <Bar dataKey="duration" name="持续时间(月)" radius={[0, 4, 4, 0]}>
                    {implementationData.map((entry, index) => (
                      <cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </div>
        </motion.div>
        
        {/* 实施阶段详情 */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {implementationPhases.map((phase, index) => (
            <motion.div
              key={index}
              className="bg-white dark:bg-gray-800 p-6 rounded-xl shadow-lg border border-gray-100 dark:border-gray-700"
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              viewport={{ once: true }}
              whileHover={{ y: -5 }}
            >
              <div className={`w-12 h-12 bg-${phase.color}-100 dark:bg-${phase.color}-900/30 rounded-lg flex items-center justify-center mb-4`}>
                <i className={`fa-solid ${phase.icon} text-${phase.color === 'red' ? 'pink' : phase.color}-600 dark:text-${phase.color === 'red' ? 'pink' : phase.color}-400 text-xl`}></i>
                </div>
              <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">{phase.phase}</h3>
              <ul className="space-y-3">
                {phase.details.map((detail, idx) => (
                  <li key={idx} className="flex items-start text-gray-600 dark:text-gray-300">
                    <i className="fa-solid fa-check-circle text-green-500 mt-1 mr-2"></i>
                    <span>{detail}</span>
                  </li>
                ))}
              </ul>
            </motion.div>
          ))}
        </div>
        
        {/* 总结与建议 */}
        <motion.div
          className="mt-16 bg-gradient-to-r from-blue-50 to-green-50 dark:from-gray-850 dark:to-gray-800 p-8 rounded-2xl shadow-xl"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
        >
          <h3 className="text-2xl font-bold text-gray-900 dark:text-white mb-6">{t('summary.section')}</h3>
          
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            <div>
              <h4 className="font-semibold text-gray-800 dark:text-white mb-4">项目总结</h4>
              <p className="text-gray-600 dark:text-gray-300 mb-4">
                越南800000㎡厂房屋顶光伏电站项目，规模大、收益稳定、合规性强，具备良好的技术可行性、经济可行性及合规可行性，同时契合越南可再生能源发展政策。
              </p>
              <p className="text-gray-600 dark:text-gray-300 mb-4">
                项目预估装机容量280-320MW，年发电量可达6.5-9亿kWh，可满足厂房大部分用电需求，每年为企业节省大量电费，同时减少碳排放，践行绿色发展理念。
              </p>
              <p className="text-gray-600 dark:text-gray-300">
                结合越南光伏扶持政策，项目投资回报稳定，静态投资回收期约6-8年，具备较强的推广价值。
              </p>
            </div>
            
            <div>
              <h4 className="font-semibold text-gray-800 dark:text-white mb-4">核心建议</h4>
              <ul className="space-y-3 text-gray-600 dark:text-gray-300">
                <li className="flex items-start">
                  <i className="fa-solid fa-lightbulb text-yellow-500 mt-1 mr-2"></i>
                  <span>前期筹备阶段强化基础调研，降低项目落地风险</span>
                </li>
                <li className="flex items-start">
                  <i className="fa-solid fa-lightbulb text-yellow-500 mt-1 mr-2"></i>
                  <span>设备选型兼顾适配性与经济性，强化数据支撑能力</span>
                </li>
                <li className="flex items-start">
                  <i className="fa-solid fa-lightbulb text-yellow-500 mt-1 mr-2"></i>
                  <span>有序推进eCNH RWA模式试点，逐步优化推广</span>
                </li>
                <li className="flex items-start">
                  <i className="fa-solid fa-lightbulb text-yellow-500 mt-1 mr-2"></i>
                  <span>建立全方位风险管控体系，强化动态调整</span>
                </li>
                <li className="flex items-start">
                  <i className="fa-solid fa-lightbulb text-yellow-500 mt-1 mr-2"></i>
                  <span>强化本地化合作，降低项目运营成本</span>
                </li>
              </ul>
            </div>
          </div>
          
          <div className="mt-8 flex justify-center">
            <motion.button
              className="inline-flex items-center px-6 py-3 bg-gradient-to-r from-blue-600 to-green-500 text-white font-medium rounded-lg shadow-lg hover:shadow-xl transition-all duration-300"
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.98 }}
            >
              <span>{t('contact.us')}</span>
              <i className="fa-solid fa-arrow-right ml-2"></i>
            </motion.button>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
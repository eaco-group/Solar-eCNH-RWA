import { useLanguage } from '../contexts/languageContext';
import { motion } from 'framer-motion';
import { PieChart, Pie, Cell, ResponsiveContainer, BarChart, Bar, XAxis, YAxis, Tooltip, Legend } from 'recharts';

// 可利用面积数据
const utilizationData = [
  { name: '可用面积', value: 70 },
  { name: '不可用面积', value: 30 }
];

// 越南各地区辐照量数据
const radiationData = [
  { name: '南部地区', value: 1500 },
  { name: '中部地区', value: 1350 },
  { name: '北部地区', value: 1200 }
];

// 项目装机容量测算数据
const capacityData = [
  { name: '保守估计', capacity: 252, area: 560 },
  { name: '推荐容量', capacity: 300, area: 600 },
  { name: '乐观估计', capacity: 340, area: 680 }
];

const COLORS = ['#3b82f6', '#93c5fd', '#60a5fa', '#bfdbfe'];

export function OverviewSection() {
  const { t } = useLanguage();
  
  return (
    <section id="overview" className="py-20 bg-white dark:bg-gray-900">
      <div className="container mx-auto px-4">
        <motion.div
          className="text-center mb-16"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
        >
          <h2 className="text-3xl font-bold text-gray-900 dark:text-white mb-4">{t('overview.section')}</h2>
          <div className="w-20 h-1 bg-gradient-to-r from-blue-500 to-green-500 mx-auto rounded-full"></div>
        </motion.div>
        
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* 厂房基础信息 */}
          <motion.div
            className="bg-white dark:bg-gray-800 p-8 rounded-2xl shadow-xl border border-gray-100 dark:border-gray-700"
            initial={{ opacity: 0, x: -20 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
          >
            <div className="flex items-center mb-6">
              <div className="w-12 h-12 bg-blue-100 dark:bg-blue-900/30 rounded-lg flex items-center justify-center mr-4">
                <i className="fa-solid fa-industry text-blue-600 dark:text-blue-400 text-xl"></i>
              </div>
              <h3 className="text-xl font-bold text-gray-900 dark:text-white">{t('overview.factory')}</h3>
            </div>
            
            <ul className="space-y-4 text-gray-600 dark:text-gray-300">
              <li className="flex items-start">
                <i className="fa-solid fa-check-circle text-green-500 mt-1 mr-2"></i>
                <span>总占地面积：800,000平方米</span>
              </li>
              <li className="flex items-start">
                <i className="fa-solid fa-check-circle text-green-500 mt-1 mr-2"></i>
                <span>可利用系数：70%-85%（预估可利用面积560,000-680,000平方米）</span>
              </li>
              <li className="flex items-start">
                <i className="fa-solid fa-check-circle text-green-500 mt-1 mr-2"></i>
                <span>常见屋顶类型：彩钢瓦（单层/双层）、混凝土屋面</span>
              </li>
              <li className="flex items-start">
                <i className="fa-solid fa-check-circle text-green-500 mt-1 mr-2"></i>
                <span>建议承重能力：≥2.5kN/㎡（含光伏组件、支架及风雪荷载）</span>
              </li>
            </ul>
            
            <div className="mt-6 h-64">
              <p className="text-sm font-medium text-gray-500 dark:text-gray-400 mb-2">屋顶可利用面积比例</p>
              <ResponsiveContainer width="100%" height="90%">
                <PieChart>
                  <Pie
                    data={utilizationData}
                    cx="50%"
                    cy="50%"
                    innerRadius={60}
                    outerRadius={80}
                    fill="#8884d8"
                    paddingAngle={5}
                    dataKey="value"
                    label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                  >
                    {utilizationData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip />
                </PieChart>
              </ResponsiveContainer>
            </div>
          </motion.div>
          
          {/* 越南当地核心政策及环境条件 */}
          <motion.div
            className="bg-white dark:bg-gray-800 p-8 rounded-2xl shadow-xl border border-gray-100 dark:border-gray-700"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            viewport={{ once: true }}
          >
            <div className="flex items-center mb-6">
              <div className="w-12 h-12 bg-green-100 dark:bg-green-900/30 rounded-lg flex items-center justify-center mr-4">
                <i className="fa-solid fa-leaf text-green-600 dark:text-green-400 text-xl"></i>
              </div>
              <h3 className="text-xl font-bold text-gray-900 dark:text-white">{t('overview.policy')}</h3>
            </div>
            
            <h4 className="font-semibold text-gray-800 dark:text-white mb-3">政策支持</h4>
            <ul className="space-y-3 text-gray-600 dark:text-gray-300 mb-6">
              <li className="flex items-start">
                <i className="fa-solid fa-check-circle text-green-500 mt-1 mr-2"></i>
                <span>补贴政策：针对分布式光伏电站的阶段性电价补贴</span>
              </li>
              <li className="flex items-start">
                <i className="fa-solid fa-check-circle text-green-500 mt-1 mr-2"></i>
                <span>并网政策：支持10kV及以上电压等级并网</span>
              </li>
              <li className="flex items-start">
                <i className="fa-solid fa-check-circle text-green-500 mt-1 mr-2"></i>
                <span>税收优惠：企业所得税减免、进口设备关税减免</span>
              </li>
            </ul>
            
            <div className="mt-6 h-64">
              <p className="text-sm font-medium text-gray-500 dark:text-gray-400 mb-2">越南各地区年太阳辐照量 (kWh/㎡)</p>
              <ResponsiveContainer width="100%" height="90%">
                <BarChart data={radiationData}>
                  <XAxis dataKey="name" />
                  <YAxis />
                  <Tooltip />
                  <Bar dataKey="value" fill="#4ade80" name="辐照量" />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </motion.div>
          
          {/* eCNH RWA模式核心认知 */}
          <motion.div
            className="bg-white dark:bg-gray-800 p-8 rounded-2xl shadow-xl border border-gray-100 dark:border-gray-700"
            initial={{ opacity: 0, x: 20 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8, delay: 0.4 }}
            viewport={{ once: true }}
          >
            <div className="flex items-center mb-6">
              <div className="w-12 h-12 bg-purple-100 dark:bg-purple-900/30 rounded-lg flex items-center justify-center mr-4">
                <i className="fa-solid fa-link text-purple-600 dark:text-purple-400 text-xl"></i>
              </div>
              <h3 className="text-xl font-bold text-gray-900 dark:text-white">{t('overview.ecnh')}</h3>
            </div>
            
            <p className="text-gray-600 dark:text-gray-300 mb-4">
              eCNH RWA即离岸人民币计价的真实世界资产，核心是将光伏电站这类具备稳定现金流、可量化估值的真实资产，与eCNH数字化结算、跨境流通优势结合，实现项目投融资、收益结算、资产流转的创新升级。
            </p>
            
            <h4 className="font-semibold text-gray-800 dark:text-white mt-6 mb-3">应用前提</h4>
            <ul className="space-y-3 text-gray-600 dark:text-gray-300">
              <li className="flex items-start">
                <i className="fa-solid fa-check-circle text-green-500 mt-1 mr-2"></i>
                <span>项目具备稳定可预期的现金流</span>
              </li>
              <li className="flex items-start">
                <i className="fa-solid fa-check-circle text-green-500 mt-1 mr-2"></i>
                <span>项目合规性达标，可通过当地政策审核及跨境资金监管要求</span>
              </li>
            </ul>
            
            <div className="mt-8">
              <p className="text-sm font-medium text-gray-500 dark:text-gray-400 mb-2">{t('ecnh.ca')}</p>
              <div className="bg-gray-100 dark:bg-gray-700 p-3 rounded-lg text-sm font-mono text-gray-700 dark:text-gray-300 break-all">
                7GQnqthWKa5v2GqXYWhmgWZY5mCRrniwK3Xuinm9GKw5
              </div>
            </div>
            
            <motion.button
              className="w-full mt-6 py-3 bg-gradient-to-r from-purple-600 to-blue-600 text-white font-medium rounded-lg shadow-md hover:shadow-lg transition-all duration-300"
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
            >
              {t('learn.more')}
            </motion.button>
          </motion.div>
        </div>
        
        {/* 装机容量测算图表 */}
        <motion.div
          className="mt-12 bg-white dark:bg-gray-800 p-8 rounded-2xl shadow-xl border border-gray-100 dark:border-gray-700"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
        >
          <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-6">项目装机容量测算</h3>
          <div className="h-72">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={capacityData}>
                <XAxis dataKey="name" />
                <YAxis yAxisId="left" orientation="left" stroke="#3b82f6" />
                <YAxis yAxisId="right" orientation="right" stroke="#4ade80" />
                <Tooltip />
                <Legend />
                <Bar yAxisId="left" dataKey="capacity" fill="#3b82f6" name="装机容量(MW)" />
                <Bar yAxisId="right" dataKey="area" fill="#4ade80" name="可利用面积(千平方米)" />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
import { useLanguage } from '../contexts/languageContext';
import { motion } from 'framer-motion';
import { RadarChart, PolarGrid, PolarAngleAxis, PolarRadiusAxis, Radar, ResponsiveContainer, Legend } from 'recharts';

// 风险评估数据
const riskAssessmentData = [
  { subject: '政策风险', A: 7, fullMark: 10 },
  { subject: '环境风险', A: 6, fullMark: 10 },
  { subject: '技术风险', A: 4, fullMark: 10 },
  { subject: '并网风险', A: 5, fullMark: 10 },
  { subject: '运维风险', A: 5, fullMark: 10 },
  { subject: 'eCNH RWA风险', A: 6, fullMark: 10 },
];

// 风险应对措施
const riskCountermeasures = [
  {
    title: '政策风险',
    description: '越南光伏补贴政策、并网政策、税收政策可能发生调整，影响项目收益及并网进度',
    countermeasures: [
      '项目启动前，委托当地专业机构核实最新政策',
      '加快项目推进速度，争取享受当前优惠政策',
      '与当地能源部门、EVN保持密切沟通',
      '委托专业合规机构，及时调整eCNH RWA应用方案'
    ]
  },
  {
    title: '环境风险',
    description: '台风、暴雨、高温、高湿度等气候条件，可能导致组件损坏、支架变形、屋顶渗漏等问题',
    countermeasures: [
      '优化支架设计，提升抗台风能力',
      '强化防水、防腐设计，避免屋面渗漏、设备腐蚀',
      '选用耐高温、耐湿度的设备，做好设备通风散热',
      '建立设备应急维修机制，故障发生后快速响应'
    ]
  },
  {
    title: '技术风险',
    description: '屋顶承重不足、组件遮挡、设备质量问题、施工质量问题，可能影响电站发电效率及运行安全',
    countermeasures: [
      '项目启动前，对屋顶进行专业承重检测',
      '优化组件布局，避免遮挡',
      '选用知名品牌设备，严格把控设备质量',
      '委托具备光伏项目施工资质的施工单位'
    ]
  },
  {
    title: 'eCNH RWA相关风险',
    description: 'eCNH RWA资产估值偏差，跨境资金结算延迟、违规，eCNH汇率波动等风险',
    countermeasures: [
      '委托专业的资产估值机构，建立科学的资产估值模型',
      '与专业的跨境结算机构合作，优化eCNH资金结算流程',
      '搭配简单的汇率对冲工具，降低eCNH自身汇率波动带来的影响',
      '完善资产确权手续，避免资产纠纷'
    ]
  }
];

export function RiskSection() {
  const { t } = useLanguage();
  
  return (
    <section id="risk" className="py-20 bg-gray-50 dark:bg-gray-850">
      <div className="container mx-auto px-4">
        <motion.div
          className="text-center mb-16"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
        >
          <h2 className="text-3xl font-bold text-gray-900 dark:text-white mb-4">{t('risk.section')}</h2>
          <div className="w-20 h-1 bg-gradient-to-r from-blue-500 to-green-500 mx-auto rounded-full"></div>
        </motion.div>
        
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* 风险评估雷达图 */}
          <motion.div
            className="lg:col-span-1 bg-white dark:bg-gray-800 p-8 rounded-2xl shadow-xl border border-gray-100 dark:border-gray-700"
            initial={{ opacity: 0, x: -20 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
          >
            <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-6">项目风险评估</h3>
            <div className="h-80">
              <ResponsiveContainer width="100%" height="100%">
                <RadarChart cx="50%" cy="50%" outerRadius="80%" data={riskAssessmentData}>
                  <PolarGrid stroke="#e5e7eb" />
                  <PolarAngleAxis dataKey="subject" tick={{ fill: '#6b7280', fontSize: 12 }} />
                  <PolarRadiusAxis angle={30} domain={[0, 10]} tick={{ fill: '#6b7280' }} />
                  <Radar name="风险等级" dataKey="A" stroke="#ef4444" fill="#ef4444" fillOpacity={0.6} />
                  <Legend />
                </RadarChart>
              </ResponsiveContainer>
            </div>
            <p className="text-sm text-gray-500 dark:text-gray-400 mt-4 text-center">风险等级：1-10分（分数越高风险越大）</p>
          </motion.div>
          
          {/* 风险应对措施 */}
          <motion.div
            className="lg:col-span-2"
            initial={{ opacity: 0, x: 20 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
          >
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {riskCountermeasures.map((risk, index) => (
                <motion.div
                  key={index}
                  className="bg-white dark:bg-gray-800 p-6 rounded-xl shadow-lg border border-gray-100 dark:border-gray-700"
                  whileHover={{ y: -5 }}
                  transition={{ duration: 0.3 }}
                >
                  <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-3">{risk.title}</h3>
                  <p className="text-gray-600 dark:text-gray-300 text-sm mb-4">{risk.description}</p>
                  
                  <h4 className="font-medium text-blue-600 dark:text-blue-400 text-sm mb-2">应对措施：</h4>
                  <ul className="space-y-2">
                    {risk.countermeasures.map((measure, idx) => (
                      <li key={idx} className="flex items-start text-sm text-gray-600 dark:text-gray-300">
                        <i className="fa-solid fa-check-circle text-green-500 mt-0.5 mr-2"></i>
                        <span>{measure}</span>
                      </li>
                    ))}
                  </ul>
                </motion.div>
              ))}
            </div>
            
            {/* 风险管控体系 */}
            <motion.div
              className="mt-6 bg-white dark:bg-gray-800 p-6 rounded-xl shadow-lg border border-gray-100 dark:border-gray-700"
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.2 }}
              viewport={{ once: true }}
            >
              <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">全方位风险管控体系</h3>
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                {[
                  { title: '合规风险管控', icon: 'fa-scale-balanced', color: 'blue' },
                  { title: '资产风险管控', icon: 'fa-shield-halved', color: 'green' },
                  { title: '资金风险管控', icon: 'fa-money-bill-wave', color: 'purple' },
                  { title: '政策风险管控', icon: 'fa-landmark', color: 'orange' }
                ].map((item, idx) => (
                  <div key={idx} className="flex items-center">
                    <div className={`w-10 h-10 bg-${item.color}-100 dark:bg-${item.color}-900/30 rounded-lg flex items-center justify-center mr-3`}>
                      <i className={`fa-solid ${item.icon} text-${item.color}-600 dark:text-${item.color}-400`}></i>
                    </div>
                    <span className="text-sm text-gray-700 dark:text-gray-300">{item.title}</span>
                  </div>
                ))}
              </div>
            </motion.div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
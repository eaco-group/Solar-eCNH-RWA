import { useLanguage } from '../contexts/languageContext';

export function useTranslate() {
  const { t } = useLanguage();
  return t;
}
import { Header } from '../components/Header';
import { HeroSection } from '../components/HeroSection';
import { OverviewSection } from '../components/OverviewSection';
import { FeasibilitySection } from '../components/FeasibilitySection';
import { DesignSection } from '../components/DesignSection';
import { ECNHSection } from '../components/ECNHSection';
import { RiskSection } from '../components/RiskSection';
import { ImplementationSection } from '../components/ImplementationSection';
import { Footer } from '../components/Footer';
import { useTheme } from '../hooks/useTheme';
import { useEffect } from 'react';

export default function Home() {
  const { theme } = useTheme();
  
  // 设置HTML的主题类
  useEffect(() => {
    document.documentElement.classList.remove('light', 'dark');
    document.documentElement.classList.add(theme);
  }, [theme]);
  
  return (
    <div className="min-h-screen bg-white dark:bg-gray-900 text-gray-800 dark:text-gray-200">
      <Header />
      <main>
        <HeroSection />
        <OverviewSection />
        <FeasibilitySection />
        <DesignSection />
        <ECNHSection />
        <RiskSection />
        <ImplementationSection />
      </main>
      <Footer />
    </div>
  );
}